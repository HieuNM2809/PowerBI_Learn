# Contoso_Dashboard
Tools: PowerBI

Data: Contoso e-commerce data

Scope: Only Sales data from 2018-2019. Focusing on products.

Audience: Sales or Marketing Department

Objectives:
  1. Monitor YoY growth of revenue
  2. Identify changes in consumer trend and top growing products sold

## PowerBI Dashboard
Model data in a star-schema.

Develop a strategic comparing revenue YoY dashboard.

Create analytics dashboard looking into products.

## Presentation
Limit to short 10 slides.

Identify winning and losing products.

Provide reccomendation on current and future stategies.
